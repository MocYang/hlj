declare global {
    interface Window {
        HikClientContainerAx: any;
        WebSocket: any;
    }
}
export {};
